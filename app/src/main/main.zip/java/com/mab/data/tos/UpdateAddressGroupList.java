package com.mab.data.tos;

public interface UpdateAddressGroupList {
    public void update();
}
